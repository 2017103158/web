<?php
include("process/db.php");

$sql = "SELECT DISTINCT
				jadwal.kelas_id,
				kelas.nama,
				kelas.semester,
				kelas.tahun
				FROM jadwal 
				INNER JOIN kelas
				ON jadwal.kelas_id = kelas.id";

$keranjang = mysqli_query($koneksi, $sql);


?>
<h1 class="page-header">Jadwal</h1>

<a href="index.php?page=jadwal-add" class="btn btn-primary">Tambah Jadwal</a>

<table class="table table-hover">
	<thead>
		<tr>
			<th>No.</th>
			<th>Kelas</th>
			<th>Semester</th>
			<th>Tahun Akademik</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
	<?php
	$i=1;
	while($row = mysqli_fetch_assoc($keranjang)){
	?>
		<tr>
			<td><?php echo $i; ?></td>
			<td><?php echo $row['nama']; ?></td>
			<td><?php echo $row['semester']; ?></td>
			<td><?php echo $row['tahun'] . "/" . ($row['tahun']+1); ?></td>
			<td>
				<a href="index.php?page=jadwal-view&kelas_id=<?php echo $row['kelas_id']; ?>" class="btn btn-xs btn-primary">View</a>
			</td>
		</tr>
	<?php
	$i++;
	}
	?>
	</tbody>
</table>