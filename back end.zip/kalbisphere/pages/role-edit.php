<h1 class="page-header">Edit Mata Kuliah</h1>

<?php
// Tahap 1. Buat koneksi Database
$host	= "localhost";
$user	= "root";
$pass	= "";
$name	= "kalbisphere";
$koneksi= mysqli_connect($host, $user, $pass, $name);

// Periksa apakah koneksi berhasil
if(mysqli_connect_errno()){
	echo "Error: ";
	echo mysqli_connect_error();
	echo "<br />Error Code: ";
	echo mysqli_connect_errno();
	die();
}

// Tahap 2. Lakukan Query SQL
$sql = "SELECT * FROM role WHERE id = $_GET[id]";
$hasil = mysqli_query($koneksi, $sql);


// Tahap 3. Tampilkan hasil Query
$row = mysqli_fetch_assoc($hasil);
?>

<form class="form-horizontal" action="process/process-role-edit.php" method="post">
 

  <div class="form-group">
    <label for="inputNama" class="col-sm-2 control-label">NAMA</label>
    <div class="col-sm-10">
      <input type="text" name="nama" class="form-control" id="inputNama" placeholder="Nama">
    </div>
  </div>

   <input type="hidden" name="id" value="<?php echo $row['id']; ?>" />
  <div class="form-group">
   <div class="col-sm-offset-2 col-sm-10">
    <button type="submit" class="btn btn-primary">Ubah</button>
   </div>
  </div>
</form>