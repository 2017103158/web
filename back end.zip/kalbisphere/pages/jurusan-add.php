<h1 class="page-header">Tambah Jurusan</h1>

<form class="form-horizontal" action="process/process-jurusan-add.php" method="post">
  <div class="form-group">
    <label for="inputKodeJurusan" class="col-sm-2 control-label">Kode Jurusan</label>
    <div class="col-sm-10">
      <input type="text" name="kode_jur" class="form-control" id="inputKodeJurusan" placeholder="Kode Jurusan">
    </div>
  </div>
  <div class="form-group">
    <label for="inputNamaJurusan" class="col-sm-2 control-label">Nama Jurusan</label>
    <div class="col-sm-10">
      <input type="text" name="nama_jur" class="form-control" id="inputNamaJurusan" placeholder="Jurusan">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary">Tambah</button>
    </div>
  </div>
</form>