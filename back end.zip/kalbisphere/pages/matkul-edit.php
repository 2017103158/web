<h1 class="page-header">Edit Mata kuliah</h1>

<?php
include("process/db.php");
// Tahap 2. Lakukan Query SQL
// Dapatkan data dari form dan bersihkan datanya
$sql = "SELECT * FROM mata_kuliah WHERE id = $_GET[id]";
$hasil= mysqli_query($koneksi, $sql);

//tahap 3. Tampilan hasil Query
$row = mysqli_fetch_assoc($hasil);

?>

<form class="form-horizontal" action="process/process-matkul-edit.php" method="post">
  <div class="form-group">
    <label for="inputKodeMatkul" class="col-sm-2 control-label">Kode</label>
    <div class="col-sm-10">
      <input type="text" name="kode_matkul" value="<?php  echo $row['kode_matkul']; ?>" class="form-control" id="inputKodeMatkul" placeholder="Kode Mata Kuliah">
    </div>
  </div>
  <div class="form-group">
    <label for="inputNamaMatkul" class="col-sm-2 control-label">Nama</label>
    <div class="col-sm-10">
      <input type="text" name="nama_matkul" value="<?php  echo $row['nama']; ?>" class="form-control" id="inputNamaMatkul" placeholder="Nama Mata Kuliah">
    </div>
  </div>
  <div class="form-group">
    <label for="inputSKSMatkul" class="col-sm-2 control-label">SKS</label>
    <div class="col-sm-10">
      <input type="text" name="SKS" value="<?php  echo $row['sks']; ?>" class="form-control" id="inputSKS" placeholder="SKS">
      <input type="hidden" name="id" value="<?php echo $row['id'] ?>" />
    </div>
  </div>

  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary">Update</button>
    </div>
  </div>
</form>