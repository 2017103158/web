<h1 class="page-header">Mahasiswa</h1>

<a href="index.php?page=mahasiswa-add" class="btn btn-primary">Tambah Mahasiswa</a>

<?php
if(isset($_GET['err']) && $_GET['err'] == "file_upload_err"){
	echo "<p> user sudah berhasil ditambahkan ke database tapi foto gagal karna ukuran atau jenis file tidak sesuai<br/>pastikan jenis file jpg/png dan ukuran dibawah 2 MB</p>";
}

// Tahap 1. Buat koneksi Database
$host	= "localhost";
$user	= "root";
$pass 	= "";
$name	= "kalbisphere";
$koneksi = mysqli_connect($host, $user, $pass, $name);

// Periksa apakah koneksi berhasil
if(mysqli_connect_errno()){
	echo "Error: ";
	echo mysqli_connect_error();
	echo "<br />Error Code: ";
	echo mysqli_connect_errno();
	die();
}

// Tahap 2. Lakukan Query SQL
// Dapatkan data dari form dan bersihkan datanya
$sql = "SELECT  mahasiswa.*,
				jurusan.nama as jurusan
				FROM mahasiswa 
				JOIN jurusan ON mahasiswa.jurusan_id = jurusan.id";		
$hasil= mysqli_query($koneksi, $sql);

?>

<table class="table table-hover">
	<thead>
		<tr>
			<th>No.</th>
			<th>Foto</th>
			<th>NIM</th>
			<th>Nama</th>
			<th>Jurusan</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
	<?php
	// Tahap 3. Tampilan hasil Query
	$i=1;
	while($row = mysqli_fetch_assoc($hasil)){
	?>
		<tr>
			<td><?php echo $i; ?></td>
			<td><img src="<?php echo $row['foto']; ?>" height="40px"></td>
			<td><?php echo $row['nim']; ?></td>
			<td><?php echo $row['nama']; ?></td>
			<td><?php echo $row['jurusan']; ?></td>
			<td>
				<a href="#" class="btn btn-xs btn-primary">View</a>
				<a href="index.php?page=mahasiswa-edit&id=<?php echo $row['id']; ?>" class="btn btn-xs btn-warning">Edit</a>
				<a href="process/process-mahasiswa-del.php?id=<?php echo $row['id']; ?>" class="btn btn-xs btn-danger">Delete</a>
			</td>
		</tr>
	<?php
	$i++;
	}
	?>
	</tbody>
</table>