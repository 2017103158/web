<?php 
include ("process/db.php");

$sql = "SELECT * FROM role";
$keranjang = mysqli_query($koneksi, $sql);
?>

<h1 class="page-header">Tambah Karyawan</h1>

<form class="form-horizontal" action="process/process-karyawan-add.php" method="post" enctype="multipart/form-data">
  <div class="form-group">
    <label class="col-sm-2 control-label">Kode Karyawan</label>
    <div class="col-sm-10">
      <input type="text" name="kode_karyawan" class="form-control" placeholder="Kode Karyawan">
    </div>
  </div>

  <div class="form-group">
    <label class="col-sm-2 control-label">Kode Dosen</label>
    <div class="col-sm-10">
      <input type="text" name="kode_dosen" class="form-control" placeholder="Kode Dosen">
    </div>
  </div>

<div class="form-group">
    <label class="col-sm-2 control-label">Nama</label>
    <div class="col-sm-10">
      <input type="text" name="nama" class="form-control" placeholder="Nama">
    </div>
  </div>

<div class="form-group">
    <label class="col-sm-2 control-label">Jenis Kelamin</label>
    <div class="col-sm-10">
      <label class="radio-inline">
        <input type="radio" name="jenis_kelamin" value="Laki-laki"> Laki-laki
      </label>
      <label class="radio-inline">
        <input type="radio" name="jenis_kelamin" value="Perempuan"> Perempuan
      </label>
    </div>
  </div>

<div class="form-group">
    <label class="col-sm-2 control-label">Foto</label>
    <div class="col-sm-10">
      <input type="file" name="foto">
    </div>
  </div>

<div class="form-group">
    <label class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
      <input type="email" name="email" class="form-control" placeholder="Email">
    </div>
  </div>

<div class="form-group">
    <label class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input type="password" name="password" class="form-control" placeholder="Password">
    </div>
  </div>

<div class="form-group">
    <label class="col-sm-2 control-label">Role</label>
    <div class="col-sm-10">
      <select name="role" class="form-control" id="InputRole">
        <option value="">Pilih Role</option>
        <?php while($row = mysqli_fetch_assoc($keranjang)) { ?>
        <option value="<?php echo $row['id']; ?>"><?php echo $row['nama']; ?></option>
        <?php } ?>
      </select>
    </div>
  </div>

  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary">Tambah</button>
    </div>
  </div>
</form>