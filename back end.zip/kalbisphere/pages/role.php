<h1 class="page-header">Role</h1>

<a href="index.php?page=role-add" class="btn btn-primary">Tambah Role</a>
<?php
// Tahap 1. Buat koneksi Database
$host	= "localhost";
$user	= "root";
$pass	= "";
$name	= "kalbisphere";
$koneksi= mysqli_connect($host, $user, $pass, $name);

// Periksa apakah koneksi berhasil
if(mysqli_connect_errno()){
	echo "Error: ";
	echo mysqli_connect_error();
	echo "<br />Error Code: ";
	echo mysqli_connect_errno();
	die();
}

// Tahap 2. Lakukan Query SQL
$sql = "SELECT * FROM role";
$hasil = mysqli_query($koneksi, $sql);
?>

<table class="table table-hover">
	<thead>
		<tr>
			<th>No.</th>
			<th>Nama Role</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>

	<?php
	// Tahap 3. Tampilkan hasil query
	$i = 1;
	while($row = mysqli_fetch_assoc($hasil)){
	?>
		<tr>
			<td><?php echo $i; ?></td>
			<td><?php echo $row['nama']; ?></td>
			<td>
				<a href="index.php?page=role-edit&id=<?php echo $row['id']; ?>" class="btn btn-xs btn-warning">Edit</a>
				<a href="process/process-role-del.php?id=<?php echo $row['id']; ?>" class="btn btn-xs btn-danger">Delete</a>
			</td>
		</tr>
	<?php
	$i++;
	}
	?>
	</tbody>
</table>