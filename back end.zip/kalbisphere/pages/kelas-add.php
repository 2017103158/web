<h1 class="page-header">Tambah Kelas</h1>

<form class="form-horizontal" action="process/process-kelas-add.php" method="post">
<div class="form-group">
    <label for="inputNamaKelas" class="col-sm-2 control-label">Kelas</label>
	<div class="col-sm-10">
	<input type="text" name="nama_kelas" class="form-control" id="inputNamaKelas" placeholder="Nama Kelas">
	</div>
</div>
<div class="form-group">
<label for="inputSemester" class="col-sm-2 control-label">Semester</label>
<div class="col-sm-10">
<input type="text" name="semester" class="form-control" id="inputSemester" placeholder="Semester">
</div> 
</div>
<div class="form-group">
<label for="inputTahun" class="col-sm-2 control-label">Tahun Akademik</label>
<div class="col-sm-10">
<input type="text" name="tahun" class="form-control" id="inputTahun" placeholder="Tahun Akademik">
</div> 
</div>

<div class="form-group">
<div class="col-sm-offset-2 col-sm-10">
<button type="submit" class="btn btn-primary">Tambah</button>
</div>
</form>