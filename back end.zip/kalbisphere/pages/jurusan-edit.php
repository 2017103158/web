<h1 class="page-header">Edit Jurusan</h1>

<?php
// Tahap 1. Buat koneksi Database
$host	= "localhost";
$user	= "root";
$pass 	= "";
$name	= "kalbisphere";
$koneksi = mysqli_connect($host, $user, $pass, $name);

// Periksa apakah koneksi berhasil
if(mysqli_connect_errno()){
	echo "Error: ";
	echo mysqli_connect_error();
	echo "<br />Error Code: ";
	echo mysqli_connect_errno();
	die();
}

// Tahap 2. Lakukan Query SQL
// Dapatkan data dari form dan bersihkan datanya
$sql = "SELECT * FROM jurusan WHERE id = $_GET[id]";
$hasil= mysqli_query($koneksi, $sql);

//tahap 3. Tampilan hasil Query
$row = mysqli_fetch_assoc($hasil);

?>

<form class="form-horizontal" action="process/process-jurusan-edit.php" method="post">
  <div class="form-group">
    <label for="inputKodeJurusan" class="col-sm-2 control-label">Kode Jurusan</label>
    <div class="col-sm-10">
      <input type="text" name="kode_jur" value="<?php echo $row['kode_jurusan']; ?>" class="form-control" id="inputKodeJurusan" placeholder="Kode Jurusan">
    </div>
  </div>
  <div class="form-group">
    <label for="inputNamaJurusan" class="col-sm-2 control-label">Nama Jurusan</label>
    <div class="col-sm-10">
      <input type="text" name="nama_jur" value="<?php echo $row['nama']; ?>" class="form-control" id="inputNamaJurusan" placeholder="Jurusan">
	  <input type="hidden" name="id" value="<?php echo $row['id'] ?>" />
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary">Ubah</button>
    </div>
  </div>
</form>