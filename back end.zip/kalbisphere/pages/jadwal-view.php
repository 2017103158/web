<?php
include("process/db.php");

$sql = "SELECT  jadwal.id,
			 	jadwal.kelas_id,
			 	jadwal.mata_kuliah_id,
			 	jadwal.karyawan_id,
			 	kelas.nama AS nama_kelas,
			 	kelas.semester,
			 	kelas.tahun,
			 	karyawan.kode_dosen,
			 	karyawan.nama AS nama_dosen,
			 	mata_kuliah.kode_matkul,
			 	mata_kuliah.nama AS nama_matkul
	 	FROM jadwal
	 	INNER JOIN kelas
	 	ON jadwal.kelas_id = kelas.id
	 	INNER JOIN karyawan
	 	ON jadwal.karyawan_id = karyawan.id
	 	INNER JOIN mata_kuliah
	 	ON jadwal.mata_kuliah_id = mata_kuliah.id 
	 	WHERE kelas_id = $_GET[kelas_id]";
$keranjang = mysqli_query($koneksi, $sql);
?>
<h1 class="page-header">Jadwal</h1>
<?php
$sql2 = "SELECT * FROM kelas WHERE id = $_GET[kelas_id]";
$hasil2 = mysqli_query($koneksi, $sql2);
$row2 = mysqli_fetch_assoc($hasil2);
?>
<p style="padding:15px;" class="bg-info text-info">
<b>
	Kelas: <?php echo $row2['nama'] ?><br />
	Semester: <?php echo $row2['semester']; ?><br />
	Tahun Akademik: <?php echo $row2['tahun'] . " / " . ($row2['tahun']+1); ?>
</b>
</p>

<table class="table table-hover">
	<thead>
		<tr>
			<th>No.</th>
			<th>Mata Kuliah</th>
			<th>Dosen</th>
			<th>Jumlah Mahasiswa</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
	<?php
 	$i = 1;
 	while($row = mysqli_fetch_assoc($keranjang)){
	?>
		<tr>
			<td><?php echo $i; ?></td>
			<td><?php echo $row['kode_matkul'] . " - " .
			$row['nama_matkul']; ?></td>
			<td><?php echo $row['nama_dosen'] . " (" .
			$row['kode_dosen'] . ")"; ?></td>
			<td>???</td>
			<td>
			<a href="index.php?page=jadwal-detil&id=<?php echo
			$row['id']; ?>" class="btn btn-xs btn-primary">View</a>
			<a href="index.php?page=jadwal-edit&id=<?php echo
			$row['id']; ?>&kelas_id=<?php echo $_GET['kelas_id']; ?>" class="btn btn-warning btn-xs">Edit</a>
			<a href="process/process-jadwal-del.php?id=<?php echo $row['id'];?>&kelas_id=<?php echo $_GET['kelas_id']; ?>" class="btn btn-danger btn-xs">Delete</a>
			</td>
		</tr>
	<?php
 	$i++;
 	}
	?>
	</tbody>
</table>
