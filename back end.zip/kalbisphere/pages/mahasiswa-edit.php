<?php
include("process/db.php");

$sql = "SELECT * FROM jurusan";
$keranjang = mysqli_query($koneksi, $sql);

$mhs_id = mysqli_real_escape_string($koneksi, $_GET['id']);
$sql2 = "SELECT * FROM mahasiswa WHERE id = $mhs_id";
$keranjang2 = mysqli_query($koneksi, $sql2);
$row2 = mysqli_fetch_assoc($keranjang2);
?>

<h1 class="page-header">Edit Mahasiswa</h1>

<form class="form-horizontal" action="process/process-mahasiswa-edit.php" method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label for="inputNIM" class="col-sm-2 control-label">NIM</label>
		<div class="col-sm-10">
			<input type="text" name="nim" value="<?php echo $row2['nim']; ?>" class="form-control" id="inputNIM" placeholder="NIM">
		</div>
	</div>
	<div class="form-group">
		<label for="inputNama" class="col-sm-2 control-label">Nama</label>
		<div class="col-sm-10">
			<input type="text" name="nama" value="<?php echo $row2['nama']; ?>" class="form-control" id="inputNama" placeholder="Nama">
		</div>
	</div>
	<div class="form-group">
		<label for="inputJurusan" class="col-sm-2 control-label">Jurusan</label>
		<div class="col-sm-10">
			<select name="jurusan" class="form-control" id="inputNIM">
				<?php
				while($row = mysqli_fetch_assoc($keranjang)){
				?>
				<option <?php echo ($row['id'] == $row2['jurusan_id'] ? 'selected':''); ?> value="<?php echo $row['id']; ?>"><?php echo $row['nama']; ?></option>
				<?php
				}
				?>
			</select>
		</div>
	</div>
	<div class="form-group">
	 <label for="inputJenisKelamin" class="col-sm-2 control-label">Jenis Kelamin</label>
	 <div class="col-sm-10">
	 	<label class="radio-inline">
	 		<input type="radio" name="jk" id="jkM" value="M" <?php echo ($row2['jenis_kelamin'] == 'M' ? 'checked':''); ?>> Laki-laki
	 	</label>
	 	<label class="radio-inline">
	 		<input type="radio" name="jk" id="jkF" value="F" <?php echo ($row2['jenis_kelamin'] == 'F' ? 'checked':''); ?>> Perempuan
	 	</label>
	 </div>
	</div>
	<div class="form-group">
		<label for="inputFoto" class="col-sm-2 control-label">Foto</label>
		<div class="col-sm-10">
			<input type="file" name="foto" id="inputFoto" />
		</div>
	</div>
	<div class="form-group">
		<label for="inputEmail" class="col-sm-2 control-label">Email</label>
		<div class="col-sm-10">
			<input type="email" name="email" value="<?php echo $row2['email']; ?>" class="form-control" id="inputEmail" placeholder="Email">
		</div>
	</div>
	<div class="form-group">
		<label for="inputPassword" class="col-sm-2 control-label">Password</label>
		<div class="col-sm-10">
			<input type="password" name="password" class="form-control" id="inputPassword" placeholder="Password">
		</div>
	</div>
	<div class="form-group">
		<div class="col-sm-offset-2 col-sm-10">
			<input type="hidden" name="id" value="<?php echo $row2['id']; ?>" />
			<button type="submit" class="btn btn-primary">Update</button>
		</div>
	</div>
</form>