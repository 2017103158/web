<?php 
include ("process/db.php");

$sql = "SELECT * FROM jurusan";
$keranjang = mysqli_query($koneksi, $sql);
?>

<h1 class="page_header">Tambah Mahasiswa</h1>

<form class="form-horizontal" action="process/process-mahasiswa-add.php" method="post" enctype="multipart/form-data">
	<div class="form-group">
    	<label for="inputNIM" class="col-sm-2 control-label">NIM</label>
	    <div class="col-sm-10">
	      	<input type="text" name="nim" class="form-control" id="inputNIM" placeholder="NIM">
	    </div>
  	</div>
  	<div class="form-group">
    	<label for="inputNama" class="col-sm-2 control-label">Nama</label>
	    <div class="col-sm-10">
	      	<input type="text" name="nama" class="form-control" id="inputNama" placeholder="Nama">
	    </div>
  	</div>
  	<div class="form-group">
    	<label for="inputJurusan" class="col-sm-2 control-label">Jurusan</label>
	    <div class="col-sm-10">
	      	<select name="jurusan" class="form-control" id="inputJurusan">
	      		<?php
	      		while ($row = mysqli_fetch_assoc($keranjang)) {
	      		?>
	      		<option value="<?php echo $row['id']; ?>"><?php echo $row['nama']; ?></option>
	      		<?php
	      		}
	      		?>
	      	</select>
	    </div>
  	</div>
  	<div class="form-group">
    	<label for="inputJenisKelamin" class="col-sm-2 control-label">Jenis Kelamin</label>
	    <div class="col-sm-10">
	      	<label class="radio-inline">
	      		<input type="radio" name="jk" id="jkM" value="M">Laki-Laki
	      	</label>
	      	<label class="radio-inline">
	      		<input type="radio" name="jk" id="jkF" value="F">Perempuan
	      	</label>
	    </div>
  	</div>
  	<div class="form-group">
    	<label for="inputFoto" class="col-sm-2 control-label">Foto</label>
	    <div class="col-sm-10">
	      	<input type="file" name="foto" id="inputFoto">
	    </div>
  	</div>
  	<div class="form-group">
    	<label for="inputEmail" class="col-sm-2 control-label">Email</label>
	    <div class="col-sm-10">
	    	<input type="email" name="email" class="form-control" id="inputEmail" placeholder="Email">
	    </div>
  	</div>
  	<div class="form-group">
    	<label for="inputPassword" class="col-sm-2 control-label">Password</label>
	    <div class="col-sm-10">
	    	<input type="password" name="password" class="form-control" id="inputPassword" placeholder="Password">
	    </div>
  	</div>
  	<div class="form-group">
	    <div class="col-sm-offset-2 col-sm-10">
	    	<button type="submit" class="btn btn-primary">Tambah</button>
	    </div>
  	</div>
</form>