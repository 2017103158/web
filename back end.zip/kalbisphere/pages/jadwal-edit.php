<?php
	
include("process/db.php");

$sql = "SELECT * FROM jadwal WHERE id = $_GET[id]";
$hasil = mysqli_query($koneksi,$sql);


//tahap 3 tampilkan
$row = mysqli_fetch_assoc($hasil);
?>
<h1 class="page-header">Edit Jadwal</h1>

<form class="form-horizontal" action="process/process-jadwal-edit.php?kelas_id=<?php echo $_GET['kelas_id']; ?>" method="post">
	<div class="form-group">
		<label for="inputKelas" class="col-sm-2 control-label">Kelas</label>
		<div class="col-sm-10">
		<select name="kelas" class="form-control">
		<?php
		$sql = "SELECT * FROM kelas WHERE id = $_GET[kelas_id]";
		$hasil = mysqli_query($koneksi, $sql);
		while($row=mysqli_fetch_assoc($hasil)){
		?>
			<option value="<?php echo $row['id']; ?>"><?php echo $row['nama'] . " (" . $row['tahun'] . " / " . ($row['tahun']+1) . ")"?></option>
		<?php
		}
		?>
		</select>
	  </div>
	 </div>
	 <div class="form-group">
		<label for="inputMatkul" class="col-sm-2 control-label">Mata Kuliah</label>
		<div class="col-sm-10">
		   <select name="matkul" class="form-control">
		   <?php
		   $sql = "SELECT * FROM mata_kuliah";
		   $hasil = mysqli_query($koneksi, $sql);
		   while($row=mysqli_fetch_assoc($hasil)){
		   ?>
		   <option value="<?php echo $row['id'] ?>"><?php echo $row['nama'] ?></option>
		   <?php
		   }
		   ?>
		 </select>
		</div>
	</div>
	<div class="form-group">
	   <label for="inputDosen" class="col-sm-2 control-label">Dosen</label>
	   <div class="col-sm-10">
	     <select name="dosen" class="form-control">
		 <?php
		 $sql = "SELECT * FROM karyawan
		         WHERE kode_dosen != ''";
	     $hasil = mysqli_query($koneksi, $sql);
		 while($row=mysqli_fetch_assoc($hasil)) {
		 ?>
		 <option value="<?php echo $row['id'] ?>"><?php echo $row['nama']; ?></option>
		 <?php
		 }
		 ?>
		</select>
	 </div>
	</div>
	<div class="form-group">
	  <div class="col-sm-offset-2 col-sm-10">
	  	<input type="hidden" name="id" value="<?php echo $_GET['id']; ?>" />
	    <button type="submit" class="btn btn-primary">Update</button>
	  </div>
	 </div>
	</form>