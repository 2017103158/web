<h1 class="page-header">Tambah Mata Kuliah</h1>

<form class="form-horizontal" action="process/process-matkul-add.php" method="post">
  <div class="form-group">
    <label for="inputKodeMatkul" class="col-sm-2 control-label">Kode</label>
    <div class="col-sm-10">
      <input type="text" name="kode_matkul" class="form-control" id="inputKodeMatkul" placeholder="Kode Mata Kuliah">
    </div>
  </div>
  <div class="form-group">
    <label for="inputNamaMatkul" class="col-sm-2 control-label">Nama</label>
    <div class="col-sm-10">
      <input type="text" name="nama_matkul" class="form-control" id="inputNamaMatkul" placeholder="Nama Mata Kuliah">
    </div>
  </div>
  <div class="form-group">
    <label for="inputSKSMatkul" class="col-sm-2 control-label">SKS</label>
    <div class="col-sm-10">
      <input type="text" name="SKS" class="form-control" id="inputSKS" placeholder="SKS">
    </div>
  </div>

  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary">Tambah</button>
    </div>
  </div>
</form>