<?php 
include("process/db.php"); 

if(isset($_SESSION['dosen']) && $_SESSION['dosen'] == 1){     
	$kary_id = $_SESSION['kary_id'];     
	$sql = "SELECT  jadwal.id,                    
					kelas.nama AS nama_kelas,                    
					kelas.semester,                    
					kelas.tahun,                    
					mata_kuliah.nama AS nama_matkul,                    
					mata_kuliah.kode_matkul             
					FROM jadwal             
					INNER JOIN kelas             
					ON jadwal.kelas_id = kelas.id             
					INNER JOIN mata_kuliah             
					ON jadwal.mata_kuliah_id = mata_kuliah.id      
					WHERE karyawan_id = $kary_id"; 
				} 
 
$keranjang = mysqli_query($koneksi, $sql); 

?> 

<h1 class="page-header">My Jadwal</h1> 
 
<table class="table table-hover">     
	<thead> 
        <tr>             
        	<th>No.</th>             
        	<th>Mata Kuliah</th>             
        	<th>Kelas</th>             
        	<th>Semester</th>             
        	<th>Tahun Akademik</th>                  
        	<th>Action</th>         
        </tr>     
    </thead>     
    <tbody>     
    	<?php     
    	$i = 1;     
    	while($row = mysqli_fetch_assoc($keranjang)){     
    		?>         
    		<tr>             
    			<td><?php echo $i; ?></td>             
    			<td><?php echo $row['kode_matkul'] . " - " . $row['nama_matkul']; ?></td>             
    			<td><?php echo $row['nama_kelas']; ?></td>             
    			<td><?php echo $row['semester']; ?></td>             
    			<td><?php echo $row['tahun'] . " / " . ($row['tahun']+1); ?></td>             
    			<td>                 
    				<a href="#" class="btn btn-xs btn-primary">Lihat Mahasiswa</a>             
    			</td>         
    			</tr>     
    			<?php     
    			$i++;     
    		}     
    		?>     
    	</tbody> 
</table>