<?php
require_once("process/db.php");
?>
<h1 class="page-header">Tambah Jadwal</h1>

<?php
if (isset($_GET['err']) && $_GET['err'] == "data_exist") {
	echo "<p style='padding:15px;' class='bg-warning text-warning'><b>Jadwal sudah ada di database. Silahkan tambahkan jadwal yang lain.</b></p>";
}
?>

<form class="form-horizontal" action="process/process-jadwal-add.php" method="post">
	<div class="form-group">
		<label for="inputKelas" class="col-sm-2 control-label">Kelas</label>
		<div class="col-sm-10">
			<select name="kelas" class="form-control">
			<?php
			 	$sql = "SELECT * FROM kelas";
			 	$hasil = mysqli_query($koneksi, $sql);
			 	while($row=mysqli_fetch_assoc($hasil)){
			?>
			<option value="<?php echo $row['id']; ?>"><?php echo
			$row['nama'] . " (" . $row['tahun'] . " / " . ($row['tahun']+1) . ")"
			?></option>
			<?php
			 	}
			?>
			</select>
		</div>
	</div>
<div class="form-group">
	<label for="inputMatkul" class="col-sm-2 control-label">Mata Kuliah</label>
	<div class="col-sm-10">
		<select name="matkul" class="form-control">
		<?php
		 	$sql = "SELECT * FROM mata_kuliah";
		 	$hasil = mysqli_query($koneksi, $sql);
		 	while($row=mysqli_fetch_assoc($hasil)){
		?>
		<option value="<?php echo $row['id'] ?>"><?php echo
		$row['nama']; ?></option>
		<?php
		 	}
		?>
		</select>
	</div>
</div>
<div class="form-group">
	<label for="inputDosen" class="col-sm-2 control-label">Dosen</label>
	<div class="col-sm-10">
		<select name="dosen" class="form-control">
		<?php
		 	$sql = "SELECT * FROM karyawan
		 	WHERE kode_dosen != ''";
		 	$hasil = mysqli_query($koneksi, $sql);
		 	while($row=mysqli_fetch_assoc($hasil)){
		?>
		<option value="<?php echo $row['id'] ?>"><?php echo
		$row['nama']; ?></option>
		<?php
		 	}
		?>
		</select>
	</div>
</div>
<div class="form-group">
<div class="col-sm-offset-2 col-sm-10">
<button type="submit" class="btn btn-primary">Tambah</button>
</div>
</div>
</form>