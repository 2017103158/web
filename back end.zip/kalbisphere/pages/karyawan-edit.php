<?php
include("process/db.php");

$sql = "SELECT * FROM role";
$keranjang = mysqli_query($koneksi, $sql);

$kar_id = mysqli_real_escape_string($koneksi, $_GET['id']);
$sql2 = "SELECT * FROM karyawan WHERE id = $_GET[id]";
$keranjang2 = mysqli_query($koneksi, $sql2);
$row2 = mysqli_fetch_assoc($keranjang2);

?>

<h1 class="page-header">Edit Karyawan</h1>

<form class="form-horizontal" action="process/process-karyawan-edit.php" method="post" enctype="multipart/form-data">
  <div class="form-group">
    <label class="col-sm-2 control-label">Kode Karyawan</label>
    <div class="col-sm-10">
      <input type="text" name="kode_karyawan" class="form-control" value="<?php echo $row2['kode_karyawan']; ?>">
    </div>
  </div>

  <div class="form-group">
    <label class="col-sm-2 control-label">Kode Dosen</label>
    <div class="col-sm-10">
      <input type="text" name="kode_dosen" class="form-control" value="<?php echo $row2['kode_dosen']; ?>">
    </div>
  </div>

<div class="form-group">
    <label class="col-sm-2 control-label">Nama</label>
    <div class="col-sm-10">
      <input type="text" name="nama" class="form-control" value="<?php echo $row2['nama']; ?>">
    </div>
  </div>

<div class="form-group">
    <label class="col-sm-2 control-label">Jenis Kelamin</label>
    <div class="col-sm-10">
      <label class="radio-inline">
        <input type="radio" name="jenis_kelamin" value="Laki-laki" <?php echo ($row2 ['jenis_kelamin'] == 'Laki-laki' ? 'checked':''); ?>> Laki-laki
      </label>
      <label class="radio-inline">
        <input type="radio" name="jenis_kelamin" value="Perempuan" <?php echo ($row2 ['jenis_kelamin'] == 'Perempuan' ? 'checked':''); ?>> Perempuan
      </label>
    </div>
  </div>

<div class="form-group">
    <label class="col-sm-2 control-label">Foto</label>
    <div class="col-sm-10">
      <input type="file" name="foto">
    </div>
  </div>

<div class="form-group">
    <label class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
      <input type="email" name="email" class="form-control" value="<?php echo$row2['email']; ?>" >
    </div>
  </div>

<div class="form-group">
    <label class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input type="password" name="password" class="form-control" placeholder="Password">
    </div>
  </div>

<div class="form-group">
    <label class="col-sm-2 control-label">Role</label>
    <div class="col-sm-10">
      <select name="role" class="form-control" id="InputRole">
        <?php while($row = mysqli_fetch_assoc($keranjang)) { ?>
	   <option  <option <?php echo ($row['id'] == $row2['role_id'] ? 'selected':''); ?> 
		 value="<?php echo $row['id']; ?>"> <?php echo $row['nama']; ?></option>
	   <?php } ?>
      </select>
    </div>
  </div>
<input type="hidden" name="id" value="<?php echo $row2['id']; ?>" />
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary">Update</button>
    </div>
  </div>
</form>