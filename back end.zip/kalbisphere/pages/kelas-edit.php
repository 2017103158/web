<h1 class="page-header">Edit Kelas</h1>

<?php
// Tahap 1. Buat koneksi Database
$host = "localhost";
$user = "root";
$pass = "";
$name = "kalbisphere";
$koneksi = mysqli_connect($host, $user, $pass, $name);

//periksa apakah koneksi berhasil
if (mysqli_connect_errno()) {
	echo "Error: ";
	echo mysqli_connect_error();
	echo "<br />Error Code: ";
	echo mysqli_connect_errno();
	die();
	}
	
// Tahap 2. Query SQL
$sql = "SELECT * FROM kelas WHERE id = $_GET[id]";
$hasil = mysqli_query($koneksi, $sql);

// Tahap 3. Tampilkan hasil Query
$row = mysqli_fetch_assoc($hasil);
?>

<form class="form-horizontal" action="process/process-kelas-edit.php" method="post">
<div class="form-group">
<label for="inputNamaKelas" class="col-sm-2 control-label">Kelas</label>
<div class="col-sm-10">
<input type="text" name="nama_kelas" value="<?php echo $row['nama'];?>"
class="form-control" id="inputNamaKelas" placeholder="Kelas">
</div>
</div>

<div class="form-group">
<label for="inputSemester" class="col-sm-2 control-label">Semester</label>
<div class="col-sm-10">
<input type="text" name="semester" value="<?php echo $row['semester']; ?>" class="form-control" id="inputSemester" placeholder="Semester">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>" />
</div> 
</div>

<div class="form-group">
<label for="inputTahun" class="col-sm-2 control-label">Tahun Akademik</label>
<div class="col-sm-10">
<input type="text" name="tahun" value="<?php echo $row['tahun']; ?>" class="form-control" id="inputTahun" placeholder="Tahun Akademik">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>" />
</div> 
</div>

<div class="form-group">
<div class="col-sm-offset-2 col-sm-10">
<button type="submit" class="btn btn-primary">Ubah</button>
</div>
</form>