
<h1 class="page-header">Tambah role</h1>

<form class="form-horizontal" action="process/process-role-add.php" method="post">
	

	<div class="form-group">
		<label for="inputNama" class="col-sm-2 control-label">NAMA</label>
		<div class="col-sm-10">
			<input type="text" name="nama" class="form-control" id="inputNama" placeholder="Nama">
		</div>
	</div>

	
	<div class="form-group">
		<div class="col-sm-offset-2 col-sm-10">
			<button type="submit" class="btn btn-primary">Tambah</button>
		</div>
	</div>			
</form>