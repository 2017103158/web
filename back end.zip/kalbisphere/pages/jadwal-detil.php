<?php
include("process/db.php");

$sql = "SELECT  jadwal_detil.id,
				jadwal_detil.jadwal_id,
 				jadwal_detil.mahasiswa_id,
				mahasiswa.nim, mahasiswa.nama
	 	FROM jadwal_detil
	 	INNER JOIN mahasiswa
	 	ON jadwal_detil.mahasiswa_id = mahasiswa.id
	 	WHERE jadwal_detil.jadwal_id = $_GET[id]";
$keranjang = mysqli_query($koneksi, $sql);
?>
<h1 class="page-header">Jadwal</h1>

<?php
$sql2 = "SELECT kelas.nama AS nama_kelas,
			 	kelas.semester,
			 	kelas.tahun,
			 	mata_kuliah.kode_matkul,
			 	mata_kuliah.nama AS nama_matkul,
			 	karyawan.kode_dosen,
			 	karyawan.nama AS nama_dosen
	 	FROM jadwal
	 	INNER JOIN kelas
	 	ON jadwal.kelas_id = kelas.id
	 	INNER JOIN mata_kuliah
		ON jadwal.mata_kuliah_id = mata_kuliah.id
	 	INNER JOIN karyawan
	 	ON jadwal.karyawan_id = karyawan.id
	 	WHERE jadwal.id = $_GET[id]";
$hasil2 = mysqli_query($koneksi, $sql2);
$row2 = mysqli_fetch_assoc($hasil2);
?>
<p style="padding:15px;" class="bg-info text-info">
	<b>
		Kelas: <?php echo $row2['nama_kelas']; ?><br />
		Semester: <?php echo $row2['semester']; ?><br />
		Tahun Akademik: <?php echo $row2['tahun'] . " / " . ($row2['tahun']+1); ?><br />
		<br />
		Mata Kuliah: <?php echo $row2['nama_matkul']; ?><br />
		Dosen: <?php echo $row2['nama_dosen'] . " (" . $row2['kode_dosen'] . ")"; ?>
	</b>
</p>

<h3>Tambah Mahasiswa</h3>
<form class="form-horizontal" action="process/process-jadwal-mhs-add.php" method="post">
	<div class="form-group">
		<label for="inputMahasiswa" class="col-sm-2 control-label">Mahasiswa</label>
		<div class="col-sm-10">
			<select name="mhs" class="form-control">
				<?php
				 	$sql3 = "SELECT DISTINCT
							 	mahasiswa.id,
							 	mahasiswa.nim,
							 	mahasiswa.nama
						 	FROM mahasiswa
						 	LEFT JOIN jadwal_detil
						 	ON mahasiswa.id = jadwal_detil.mahasiswa_id
						 	WHERE jadwal_detil.mahasiswa_id IS NULL OR jadwal_detil.jadwal_id !=$_GET[id]";
						 	$hasil3 = mysqli_query($koneksi, $sql3);
						 	while($row3 = mysqli_fetch_assoc($hasil3)){
				 ?>
				<option value="<?php echo $row3['id']; ?>"><?php echo $row3['nim'] . " - " . $row3['nama']; ?></option>
				<?php
				 }
				?>
			</select>
		</div>
	</div>
<div class="form-group">
	<div class="col-sm-offset-2 col-sm-10">
		<input type="hidden" name="jadwal_id" value="<?php echo
		$_GET['id']; ?>" />
		<button type="submit" class="btn btn-primary">Tambah Mahasiswa</button>
	</div>
</div>
</form>

<table class="table table-hover">
<thead>
	<tr>
		<th>No.</th>
		<th>NIM</th>
		<th>Mahasiswa</th>
		<th>Action</th>
	</tr>
</thead>
<tbody>
<?php
$i = 1;
while($row = mysqli_fetch_assoc($keranjang)){
?>
	<tr>
		<td><?php echo $i; ?></td>
		<td><?php echo $row['nim']; ?></td>
		<td><?php echo $row['nama']; ?></td>
		<td>
		<a href="process/process-jadwal-detil-del.php?id=<?php echo $row['id'];?>&jadwal_id=<?php echo $_GET['id']; ?>" class="btn btn-xs btn-danger">Drop Mahasiswa</a> 
		</td>
	</tr>
<?php
 	$i++;
 	}
?>
</tbody>
</table>