
<!DOCTYPE html> 
<html lang="en"> 
<?php

if(isset($_GET['errmsg']) && $_GET['errmsg'] == "1"){
    echo "<p>PASSWORD tidak sesuai</p>";}
if(isset($_GET['errmsg']) && $_GET['errmsg'] == "2"){
    echo "<p>MAHASISWA belum terdaftar</p>";
}?>

<?php include("template/head.php"); ?> 
 
 <body> 
 
    <div class="container"> 

        <form class="form-signin" action="process/process-login.php" method="post">         
        	<h2 class="form-signin-heading">KALBISPHERE | Sign in</h2>         
        	<div class="form-group">             
        		<label for="inputKalbiserID" class="sr-only">Kalbiser ID</label>             
        		<input type="text" id="inputKalbiserID" name="kalbis_id" class="form-control" placeholder="Kalbiser ID" required autofocus>         
        	</div>         
        	<div class="form-group">             
        		<label for="inputPassword" class="sronly">Password</label>
        		<input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" required>         
        	</div>         
        	<button class="btn btn-primary btn-block" type="submit">Sign in</button>       
        </form> 

    </div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js "></script>
<script>window.jQuery || document.write('<script src="assets/js/vendor/jquery.min.js"><\/script>')</script>     
<script src="dist/js/bootstrap.min.js"></script>    
<script src="assets/js/vendor/holder.min.js"></script>   
<script src="assets/js/ie10-viewport-bug-workaround.js">
</script>   
</body> 
</html>