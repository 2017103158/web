<?php
$class_home = "";
$class_jurusan = "";
$class_mahasiswa = "";
$class_matkul = "";
$class_kelas = "";
$class_role = "";
$class_karyawan = "";
$class_jadwal = "";
$class_myjadwal = "";
if(isset($_GET['page'])){
	$page = $_GET['page'];
}else{
	$page = "";
}
switch($page){
	case "jurusan":
	case "jurusan-add":
	case "jurusan-edit": $class_jurusan = "active"; break;

	case "mahasiswa":
	case "mahasiswa-add":
	case "mahasiswa-edit": $class_mahasiswa = "active"; break;

	case "matkul":
	case "matkul-add":
	case "matkul-edit": $class_matkul = "active"; break;

	case "kelas":
	case "kelas-add":
	case "kelas-edit": $class_kelas = "active"; break;

	case "role":
	case "role-add":
	case "role-edit": $class_role = "active"; break;

	case "karyawan":
	case "karyawan-add":
	case "karyawan-edit": $class_karyawan = "active"; break;

	case "jadwal":
	case "jadwal-view":
	case "jadwal-detil":
	case "jadwal-add":
	case "jadwal-edit": $class_jadwal = "active"; break;

	case "myjadwal": $class_myjadwal = "myjadwal"; break;

	default: $class_home = "active";
}
?>

  <ul class="nav nav-sidebar">
	<li class="<?php echo $class_home; ?>"><a href="#">Overview <span class="sr-only">(current)</span></a></li>

	<?php
	if(isset($_SESSION['role_id']) && $_SESSION['role_id'] == 1){
	?>

	<li class="<?php echo $class_jurusan; ?>"><a href="index.php?page=jurusan">Jurusan</a></li>
	<li class="<?php echo $class_matkul; ?>"><a href="index.php?page=matkul">Mata Kuliah</a></li>
	<li class="<?php echo $class_kelas; ?>"><a href="index.php?page=kelas">Kelas</a></li>
	<li class="<?php echo $class_role; ?>"><a href="index.php?page=role">Role</a></li>
	<li class="<?php echo $class_karyawan; ?>"><a href="index.php?page=karyawan">Karyawan</a></li>
	<li class="<?php echo $class_mahasiswa; ?>"><a href="index.php?page=mahasiswa">Mahasiswa</a></li>
	<li class="<?php echo $class_jadwal; ?>"><a href="index.php?page=jadwal">Jadwal</a></li>
	<li class="<?php echo $class_myjadwal; ?>"><a href="index.php?page=myjadwal">My Jadwal</a></li>
	<?php
	}
	if(isset($_SESSION['dosen']) && $_SESSION['dosen'] == 1){
	?>

	<li class="<?php echo $class_myjadwal; ?>"><a href="index.php?page=myjadwal">My Jadwal</a></li>

	<?php
	}if(isset($_SESSION['mhs']) && $_SESSION['mhs'] == 1){
	?>
	<li class="<?php echo $class_mahasiswa; ?>"><a href="index.php?page=mahasiswa">Mahasiswa</a></li>
	<?php
	}if(isset($_SESSION['karyawan']) && $_SESSION['karyawan'] == 1 && $_SESSION['role_id'] != 1){
	?>
	<li class="<?php echo $class_karyawan; ?>"><a href="index.php?page=karyawan">Karyawan</a></li>
	<?php
	}
	?>
  </ul>