-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 15 Apr 2018 pada 10.45
-- Versi Server: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kalbisphere`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal`
--

CREATE TABLE IF NOT EXISTS `jadwal` (
  `id` int(11) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `mata_kuliah_id` int(11) NOT NULL,
  `karyawan_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jadwal`
--

INSERT INTO `jadwal` (`id`, `kelas_id`, `mata_kuliah_id`, `karyawan_id`) VALUES
(10, 11, 5, 67),
(12, 12, 13, 67),
(13, 14, 12, 68),
(14, 13, 8, 68),
(15, 15, 9, 67);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal_detil`
--

CREATE TABLE IF NOT EXISTS `jadwal_detil` (
  `id` int(11) NOT NULL,
  `jadwal_id` int(11) NOT NULL,
  `mahasiswa_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jadwal_detil`
--

INSERT INTO `jadwal_detil` (`id`, `jadwal_id`, `mahasiswa_id`) VALUES
(60, 10, 5),
(64, 12, 4),
(65, 14, 5),
(66, 13, 4),
(67, 15, 5),
(68, 10, 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurusan`
--

CREATE TABLE IF NOT EXISTS `jurusan` (
  `id` int(11) NOT NULL,
  `kode_jurusan` varchar(10) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jurusan`
--

INSERT INTO `jurusan` (`id`, `kode_jurusan`, `nama`) VALUES
(6, 'IF', 'Informatika'),
(7, 'MN', 'Manajemen'),
(8, 'SI', 'Sistem Informasi'),
(9, 'BC', 'Broadcast'),
(10, 'DKV', 'Desain komunikasi visual');

-- --------------------------------------------------------

--
-- Struktur dari tabel `karyawan`
--

CREATE TABLE IF NOT EXISTS `karyawan` (
  `id` int(11) NOT NULL,
  `kode_karyawan` varchar(10) NOT NULL,
  `kode_dosen` varchar(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis_kelamin` char(10) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `karyawan`
--

INSERT INTO `karyawan` (`id`, `kode_karyawan`, `kode_dosen`, `nama`, `jenis_kelamin`, `foto`, `email`, `password`, `role_id`) VALUES
(66, 'K001', '', 'Ivan', 'Laki-laki', 'uploads/karyawan/Ivan.jpg', 'ivan@gmail.com', '$2y$10$.VZ/a7k.BhvDNBSjiSwF4OlsRtJG9Ru5py.nx96yqm6AuKXrEclJm', 11),
(67, 'K002', 'D001', 'Adi', 'Laki-laki', 'uploads/karyawan/Adi.jpg', 'adi@gmail.com', '$2y$10$E99vaIdZ3xuOSe86DOZPEOsw.xrwUExLvgHVEw7xRnS2ftFhHUC0O', 10),
(68, 'K003', 'D002', 'Rya', 'Perempuan', 'uploads/karyawan/Rya.jpg', 'rya@gmail.com', '$2y$10$Tc4xszuHXvSUX34iCRNvJeGhk.5wA7Q7HssiyE8K5qrzrWsbyakq.', 10),
(69, 'Admin', '', 'Admin', 'Laki-laki', 'uploads/karyawan/Admin.jpg', 'W@gmail.com', '$2y$10$bAkmZP4MZqSJhcg6tzaPn.5YHLgKJNz8qB6OX.3/EDkGXSFQAGXGu', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kelas`
--

CREATE TABLE IF NOT EXISTS `kelas` (
  `id` int(11) NOT NULL,
  `nama` varchar(10) NOT NULL,
  `semester` int(11) NOT NULL,
  `tahun` year(4) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kelas`
--

INSERT INTO `kelas` (`id`, `nama`, `semester`, `tahun`) VALUES
(11, '01PAIF', 1, 2017),
(12, '03PBSI', 3, 2016),
(13, '01PABC', 1, 2017),
(14, '03PADKV', 3, 2016),
(15, '01PCMN', 1, 2017);

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE IF NOT EXISTS `mahasiswa` (
  `id` int(11) NOT NULL,
  `nim` varchar(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jurusan_id` int(11) NOT NULL,
  `jenis_kelamin` char(1) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mahasiswa`
--

INSERT INTO `mahasiswa` (`id`, `nim`, `nama`, `jurusan_id`, `jenis_kelamin`, `foto`, `email`, `password`) VALUES
(4, '2017103123', 'Predy', 8, 'M', 'uploads/mahasiswa/Predy.png', 'predy@gmail.com', '$2y$10$.KaeQ2PTmwma1lKps4EEpuQMdXjncTIaNxnUQE5O7JDziz7EqOjGS'),
(5, '2017103124', 'Rya', 6, 'F', 'uploads/mahasiswa/Rya.jpg', 'rya@gmail.com', '$2y$10$mIs2gB3QhiqQlp72cxIti.4LxkC4oqvNnIf10fP3UnoxAsBH8ts2i');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mata_kuliah`
--

CREATE TABLE IF NOT EXISTS `mata_kuliah` (
  `id` int(11) NOT NULL,
  `kode_matkul` varchar(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `sks` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mata_kuliah`
--

INSERT INTO `mata_kuliah` (`id`, `kode_matkul`, `nama`, `sks`) VALUES
(5, 'IF001', 'Algoritma', 3),
(6, 'IF002', 'Web', 3),
(7, 'BC001', 'Desain grafis', 2),
(8, 'BC002', 'Film', 4),
(9, 'MN001', 'Leadership', 2),
(10, 'MN002', 'Time manajemen', 1),
(11, 'DKV001', 'Animasi', 3),
(12, 'DKV002', 'Komunikasi visual', 2),
(13, 'SI001', 'Database', 2),
(14, 'SI002', 'Manajemen sistem', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) NOT NULL,
  `nama` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `role`
--

INSERT INTO `role` (`id`, `nama`) VALUES
(1, 'Admin'),
(10, 'Dosen'),
(11, 'Karyawan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kelas_id` (`kelas_id`),
  ADD KEY `mata_kuliah_id` (`mata_kuliah_id`),
  ADD KEY `karyawan_id` (`karyawan_id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_2` (`id`),
  ADD KEY `karyawan_id_2` (`karyawan_id`);

--
-- Indexes for table `jadwal_detil`
--
ALTER TABLE `jadwal_detil`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jadwal_id` (`jadwal_id`),
  ADD KEY `mahasiswa_id` (`mahasiswa_id`);

--
-- Indexes for table `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_jurusan` (`kode_jurusan`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`),
  ADD KEY `kode_karyawan` (`kode_karyawan`);

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nim` (`nim`),
  ADD KEY `jurusan_id` (`jurusan_id`);

--
-- Indexes for table `mata_kuliah`
--
ALTER TABLE `mata_kuliah`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_matkul` (`kode_matkul`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jadwal`
--
ALTER TABLE `jadwal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `jadwal_detil`
--
ALTER TABLE `jadwal_detil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT for table `jurusan`
--
ALTER TABLE `jurusan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `karyawan`
--
ALTER TABLE `karyawan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=70;
--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `mata_kuliah`
--
ALTER TABLE `mata_kuliah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `jadwal`
--
ALTER TABLE `jadwal`
  ADD CONSTRAINT `jadwal_ibfk_2` FOREIGN KEY (`mata_kuliah_id`) REFERENCES `mata_kuliah` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `jadwal_ibfk_4` FOREIGN KEY (`karyawan_id`) REFERENCES `karyawan` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `jadwal_ibfk_5` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `jadwal_detil`
--
ALTER TABLE `jadwal_detil`
  ADD CONSTRAINT `jadwal_detil_ibfk_1` FOREIGN KEY (`jadwal_id`) REFERENCES `jadwal` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `jadwal_detil_ibfk_2` FOREIGN KEY (`mahasiswa_id`) REFERENCES `mahasiswa` (`id`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `karyawan`
--
ALTER TABLE `karyawan`
  ADD CONSTRAINT `karyawan_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD CONSTRAINT `mahasiswa_ibfk_1` FOREIGN KEY (`jurusan_id`) REFERENCES `jurusan` (`id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
