<?php // db.php

// DB Credential constants
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_NAME", "kalbisphere");

// buat koneksi
$koneksi = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

// periksa jika ada kesalahan koneksi DB
if(mysqli_connect_errno()){
	echo "Error: ";
	echo mysqli_connect_error();
	echo "<br />Error Code: ";
	echo mysqli_connect_errno();
	die();
}


 ?>