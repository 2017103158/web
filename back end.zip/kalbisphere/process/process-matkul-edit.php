<?php //process-mahasiswa-edit.php 
include("db.php"); 
 
// Form Data 
$kodematkul = mysqli_real_escape_string($koneksi, $_POST['kode_matkul']);
$namamatkul = mysqli_real_escape_string($koneksi, $_POST['nama_matkul']);
$sks = mysqli_real_escape_string($koneksi, $_POST['SKS']);
       
$sql = "UPDATE mata_kuliah             
		SET kode_matkul = '$kodematkul',                 
			nama = '$namamatkul',                 
			sks = '$sks'      
		WHERE id = $_POST[id]"; 

 
mysqli_query($koneksi, $sql); 
 
header('Location: ../index.php?page=matkul');
?>