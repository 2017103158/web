<?php
include ("db.php");

$sql = "DELETE FROM mahasiswa WHERE id = $_GET[id]";
mysqli_query($koneksi, $sql);

// Redirect ke halaman jurusan
header('Location: ../index.php?page=mahasiswa');
?>