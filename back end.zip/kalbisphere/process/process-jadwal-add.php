<?php
require_once("db.php");

$kelas_id = $_POST['kelas'];
$matkul_id = $_POST['matkul'];
$kary_id = $_POST['dosen'];

$sql = "SELECT * FROM jadwal
		WHERE kelas_id = $kelas_id
			AND mata_kuliah_id = $matkul_id
			AND karyawan_id = $kary_id";
$hasil = mysqli_query($koneksi, $sql);

if (mysqli_num_rows($hasil)) {
	header('Location: ../index.php?page=jadwal-add&err=data_exist');
}else{
	$sql = "INSERT INTO jadwal(kelas_id, mata_kuliah_id, karyawan_id)
			VALUES ($kelas_id, $matkul_id, $kary_id)";
	mysqli_query($koneksi, $sql);
	header('Location: ../index.php?page=jadwal');
}