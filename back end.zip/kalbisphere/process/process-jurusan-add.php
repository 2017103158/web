<?php
// Tahap 1. Buat koneksi Database
$host	= "localhost";
$user	= "root";
$pass 	= "";
$name	= "kalbisphere";
$koneksi = mysqli_connect($host, $user, $pass, $name);

// Periksa apakah koneksi berhasil
if(mysqli_connect_errno()){
	echo "Error: ";
	echo mysqli_connect_error();
	echo "<br />Error Code: ";
	echo mysqli_connect_errno();
	die();
}

// Tahap 2. Lakukan Query SQL
// Dapatkan data dari form dan bersihkan datanya
$kode_jur = mysqli_real_escape_string($koneksi, $_POST['kode_jur']);
$nama_jur = mysqli_real_escape_string($koneksi, $_POST['nama_jur']);

$sql = "INSERT INTO jurusan (kode_jurusan, nama)
		VALUES ('$kode_jur','$nama_jur')";
mysqli_query($koneksi, $sql);

// Redirect ke halaman jurusan
header('Location: ../index.php?page=jurusan');
?>