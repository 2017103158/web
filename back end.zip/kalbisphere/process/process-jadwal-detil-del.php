<?php 
include("db.php");


$sql = "DELETE FROM jadwal_detil
		WHERE id=$_GET[id]";

$jadwal_id = $_GET['jadwal_id'];
mysqli_query($koneksi,$sql);

header("Location: ../index.php?page=jadwal-detil&id=$jadwal_id");

?>