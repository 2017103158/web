<?php
session_start(); 
 
require_once("db.php"); 
 
$kalbiser_id = mysqli_real_escape_string($koneksi, $_POST['kalbis_id']); 
$password    = mysqli_real_escape_string($koneksi, $_POST['password']); 
 

$sql = "SELECT * FROM 	karyawan         
		WHERE 			kode_karyawan = '$kalbiser_id'        
		OR 				kode_dosen = '$kalbiser_id'"; 
$hasil = mysqli_query($koneksi, $sql); 
 

if(mysqli_num_rows($hasil)){
$row = mysqli_fetch_assoc($hasil);

		if(password_verify($password, $row['password'])){


		$_SESSION['login'] = 1;
		$_SESSION['role_id'] = $row['role_id'];        
		$_SESSION['karyawan'] = 1;         
		$_SESSION['kary_id'] = $row['id'];

       
		if(!empty($row['kode_dosen'])){             
		$_SESSION['dosen'] = 1;
		}                  


		header('Location: ../index.php');     
		}

		else{
		header('Location: ../login.php?errmsg=1');
		}

}



else{      
		$sql = "SELECT * FROM mahasiswa             
				WHERE nim = '$kalbiser_id'";     
		$hasil = mysqli_query($koneksi, $sql);

		if(mysqli_num_rows($hasil)){


			$row = mysqli_fetch_assoc($hasil);

			if(password_verify($password, $row['password'])){

	      
			$_SESSION['login'] = 1;       
			$_SESSION['mhs'] = 1;            
			$_SESSION['mhs_id'] = $row['id'];                          
			header('Location: ../index.php');

			}

			else{
			
		header('Location: ../login.php?errmsg=1');               
			}     
		}

		else{  
		header('Location: ../login.php?errmsg=2');
		} 
}