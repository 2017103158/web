<?php 

include("db.php");

// form data
$nim = mysqli_real_escape_string($koneksi, $_POST['nim']);
$nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
$password = mysqli_real_escape_string($koneksi, $_POST['password']);
$password = password_hash($password, PASSWORD_BCRYPT);
$jurusan = $_POST['jurusan'];
$jk = $_POST['jk'];
$email = $_POST['email'];

$size = $_FILES['foto']['size'];
$ext = explode(".", $_FILES['foto']['name']);
$ext = end($ext);
$ext = strtolower($ext);

$ext_boleh = array("jpg","jpeg","png");

echo $ext;
echo $size;
echo in_array($ext, $ext_boleh);
if($size <= 2*1024*1024 && in_array($ext, $ext_boleh)){
	$sumber = $_FILES['foto']['tmp_name'];
	$tujuan = "../uploads/mahasiswa/".$nama.".".$ext;
	$file_path = "uploads/mahasiswa/".$nama.".".$ext;
	move_uploaded_file($sumber, $tujuan);
}else{
	$file_path = "";
	$err_msg = "file_upload_err";
}

// Proses Query
$sql = "INSERT INTO mahasiswa (nim, nama, jurusan_id, jenis_kelamin, foto, email, password)
	VALUES('$nim', '$nama', '$jurusan', '$jk', '$file_path', '$email', '$password')";
mysqli_query($koneksi, $sql);

header('Location: ../index.php?page=mahasiswa&err_msg');
?>