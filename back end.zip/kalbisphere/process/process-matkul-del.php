<?php
include ("db.php");

$sql = "DELETE FROM mata_kuliah WHERE id = $_GET[id]";
mysqli_query($koneksi, $sql);

// Redirect ke halaman jurusan
header('Location: ../index.php?page=matkul');
?>