<?php

require_once("db.php");

$kelas = $_POST['kelas'];
$matkul_id = $_POST['matkul'];
$kary_id = $_POST['dosen'];

$sql = "UPDATE jadwal
		SET kelas_id = '$kelas',
			mata_kuliah_id = '$matkul_id',
			karyawan_id = '$kary_id'
		WHERE id = $_POST[id]";
$kelas_id = $_GET['kelas_id'];
$hasil = mysqli_query($koneksi,$sql);
header("Location: ../index.php?page=jadwal-view&kelas_id=$kelas_id");
?>