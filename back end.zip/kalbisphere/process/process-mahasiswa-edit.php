<?php //process-mahasiswa-edit.php 
include("db.php"); 
 
// Form Data 
$nim = mysqli_real_escape_string($koneksi, $_POST['nim']); 
$nama = mysqli_real_escape_string($koneksi, $_POST['nama']); 
$password = mysqli_real_escape_string($koneksi, $_POST['password']); 
$password = password_hash($password, PASSWORD_BCRYPT);
$jurusan = $_POST['jurusan']; 
$jk      = $_POST['jk']; 
$email   = $_POST['email']; 
 
$size = $_FILES['foto']['size'];
$ext = explode(".", $_FILES['foto']['name']);
$ext = end($ext);
$ext = strtolower($ext);

$ext_boleh = array("jpg","jpeg","png");

echo $ext;
echo $size;
echo in_array($ext, $ext_boleh);
if($size <= 2*1024*1024 && in_array($ext, $ext_boleh)){
	$sumber = $_FILES['foto']['tmp_name'];
	$tujuan = "../uploads/mahasiswa/".$nama.".".$ext;
	$file_path = "uploads/mahasiswa/".$nama.".".$ext;
	move_uploaded_file($sumber, $tujuan);
}else{
	$file_path = "";
	$err_msg = "file_upload_err";
}

// Periksa apakah Input Password ada Isinya 
if(empty($password)){     
// jika password kosong, maka password tidak di update     
	$sql = "UPDATE mahasiswa             
			SET nim = '$nim',                 
				nama = '$nama',                 
				jurusan_id = $jurusan,                 
				jenis_kelamin = '$jk',
				foto = '$file_path',                 
				email = '$email'             
			WHERE id = $_POST[id]"; 
			}else{     
			// jika password diisi, maka password diupdate     
				$sql = "UPDATE mahasiswa             
						SET nim = '$nim',                 
							nama = '$nama',                 
							jurusan_id = $jurusan,                 
							jenis_kelamin = '$jk', 
							foto = '$file_path',                 
							email = '$email',                 
							password = '$password'             
							WHERE id = $_POST[id]"; 
} 
 
mysqli_query($koneksi, $sql); 
 
header('Location: ../index.php?page=mahasiswa');
?>