<?php
include("db.php");
$kode_karyawan = mysqli_real_escape_string($koneksi, $_POST['kode_karyawan']);
$kode_dosen = mysqli_real_escape_string($koneksi, $_POST['kode_dosen']);
$nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
$password = mysqli_real_escape_string($koneksi, $_POST['password']);
$password = password_hash($password, PASSWORD_BCRYPT);
$role = $_POST['role'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$email = $_POST['email'];

$size = $_FILES['foto']['size'];
$ext = explode(".", $_FILES['foto']['name']);
$ext = end($ext);
$ext = strtolower($ext);

$ext_boleh = array("jpg","jpeg","png");

echo $ext;
echo $size;
echo in_array($ext, $ext_boleh);
if($size <= 2*1024*1024 && in_array($ext, $ext_boleh)){
	$sumber = $_FILES['foto']['tmp_name'];
	$tujuan = "../uploads/karyawan/".$nama.".".$ext;
	$file_path = "uploads/karyawan/".$nama.".".$ext;
	move_uploaded_file($sumber, $tujuan);
}else{
	$file_path = "";
	$err_msg = "file_upload_err";
}

$sql = "UPDATE karyawan
		SET kode_karyawan = '$kode_karyawan', 
		kode_dosen = '$kode_dosen',
		nama = '$nama', 
		role_id = '$role', 
		jenis_kelamin = '$jenis_kelamin', 
		password = '$password', 
		foto = '$file_path',
		email = '$email'
		WHERE id = $_POST[id]";

mysqli_query($koneksi, $sql);
header('Location: ../index.php?page=karyawan'); 