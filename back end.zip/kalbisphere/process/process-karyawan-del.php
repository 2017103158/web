<?php 
include("db.php");

$sql = "DELETE FROM karyawan
        WHERE id = $_GET[id]";
		mysqli_query($koneksi, $sql);
		
header ('Location: ../index.php?page=karyawan');

?>