<?php 
// Tahap 1. Buat koneksi Database

$host = "localhost";
$user = "root";
$pass = "";
$name = "kalbisphere";
$koneksi = mysqli_connect($host, $user, $pass, $name);

// Periksa apakah koneksi berhasil

if(mysqli_connect_errno()){
	echo "Error: ";
	echo mysqli_connect_error();
	echo "<br />Error Code: ";
	echo mysqli_connect_errno();
	die();
}

// Tahap 2. Lakukan Query SQL
// Dapatkan data dari form dan bersihkan datanya
$nama_kelas = mysqli_real_escape_string($koneksi, $_POST['nama_kelas']);
$semester = mysqli_real_escape_string($koneksi, $_POST['semester']);
$tahun = mysqli_real_escape_string($koneksi, $_POST['tahun']);

$sql = "INSERT INTO kelas (nama, semester, tahun)
        VALUES ('$nama_kelas', '$semester', '$tahun')";
mysqli_query($koneksi, $sql);

// Redirect ke halaman kelas

header('Location: ../index.php?page=kelas');

?>