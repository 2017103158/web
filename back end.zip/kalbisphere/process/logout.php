<?php

session_start();

$_SESSION['login'] = null;
$_SESSION['role_id'] = null;
$_SESSION['karyawan'] = null;
$_SESSION['mhs'] = null;
$_SESSION['mhs_id'] = null;
$_SESSION['dosen'] = null;
header('Location: ../login.php');
?>