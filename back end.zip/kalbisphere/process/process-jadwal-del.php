<?php 
include("db.php");

$sql = "DELETE FROM jadwal
		WHERE id=$_GET[id]";

$kelas_id = $_GET['kelas_id'];
mysqli_query($koneksi,$sql);

header("Location: ../index.php?page=jadwal-view&kelas_id=$kelas_id");

?>