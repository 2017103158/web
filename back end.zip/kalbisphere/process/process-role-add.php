<?php //process-mahasiswa-add.php
include("db.php");

// Form Data


$nama = mysqli_real_escape_string($koneksi, $_POST['nama']);

//process Query

$sql = "INSERT INTO role(nama)
		VALUES ('$nama')";
mysqli_query($koneksi, $sql);

header('location: ../index.php?page=role');
		