<?php 

include("db.php");

// form data
$kodematkul = mysqli_real_escape_string($koneksi, $_POST['kode_matkul']);
$namamatkul = mysqli_real_escape_string($koneksi, $_POST['nama_matkul']);
$sks = mysqli_real_escape_string($koneksi, $_POST['SKS']);


// Proses Query
$sql = "INSERT INTO mata_kuliah (kode_matkul, nama, sks)
	VALUES('$kodematkul', '$namamatkul', '$sks')";
mysqli_query($koneksi, $sql);

header('Location: ../index.php?page=matkul');
?>