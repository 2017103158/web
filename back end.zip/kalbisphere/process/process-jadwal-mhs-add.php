<?php
require_once("db.php");

$sql = "INSERT INTO jadwal_detil(jadwal_id, mahasiswa_id)
		VALUES($_POST[jadwal_id], $_POST[mhs])";
mysqli_query($koneksi, $sql);

$jadwal_id = $_POST['jadwal_id'];

if (mysqli_error($koneksi)) {
	echo mysqli_error($koneksi);
}

header("Location: ../index.php?page=jadwal-detil&id=$jadwal_id");